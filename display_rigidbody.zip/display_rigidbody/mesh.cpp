#include "mesh.hpp"

void Mesh::add(Node* node)
{
    this->nodes.push_back(node);
}

void Mesh::add(Vert* vert)
{
    this->verts.push_back(vert);
}

void Mesh::add(Face* face)
{
    this->faces.push_back(face);
}

void Mesh::add(Norm* norm)
{
    this->norms.push_back(norm);
}

void connect(Vert *vert, Node* node)
{
    vert->node = node;
    include(vert, node->verts);
}
