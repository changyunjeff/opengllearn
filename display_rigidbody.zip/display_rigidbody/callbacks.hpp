#ifndef CALLBACKS_HPP
#define CALLBACKS_HPP
#include <iostream>
#include <gl/glut.h>

struct GlutCallbacks {
    void (*idle) ();
    void (*keyboard) (unsigned char, int, int);
    void (*special) (int, int, int);
    void (*reshape) (int w, int h);
    void (*mouse) (int button, int state, int x, int y);
    void (*motion) (int x, int y);
    GlutCallbacks (): idle(NULL), keyboard(NULL), special(NULL) {}
};

void reshape(int w, int h);

void mouse(int button, int state, int x, int y);

void motion(int x, int y);

#endif