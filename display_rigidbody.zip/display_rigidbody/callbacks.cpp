#include "callbacks.hpp"

void reshape(int w, int h)
{
    if(h==0)
        h==1;
    float ratio = w*1.0 / h;
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glViewport(0, 0, w, h);
    gluPerspective(45, ratio, 1, 100);
    glMatrixMode(GL_MODELVIEW);
}

void mouse(int button, int state, int x, int y)
{

}

void motion(int x, int y)
{

}