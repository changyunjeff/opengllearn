#ifndef __TIMER_H
#define __TIMER_H

#include <time.h>
#include <cstdlib>
#include <iostream>
#include <boost/date_time/posix_time/posix_time.hpp>

class Timer {
public:
    boost::posix_time::ptime then;
    double last, total;
    Timer ();
    void tick (), tock ();
};

#endif