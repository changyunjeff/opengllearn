#ifndef MESH_HPP
#define MESH_HPP

#include <vector>
#include "vectors.hpp"
#include "utils.hpp"

class Vert;
class Node;
class Face;
class Norm;

//纹理坐标
class Vert{
public:
    Vec2 u;
    Node* node;
    // constructors
    Vert(){}
    explicit Vert(const Vec2 &u):u(u){}
};

class Node{
public:
    Vec3 x;//posiotion
    std::vector<Vert*> verts;
    // constructors
    Node(){}
    explicit Node(const Vec3 &x):x(x) {}
};

class Norm{
public:
    Vec3 v;
    Norm(){};
    explicit Norm(const Vec3 &v):v(v) {};
};

class Face{
public:
    Node* node[3];
    Vert* vert[3];//三角面的三个纹理坐标
    Vec3 norm;     //三角面的法向量
    // constructors
    Face(){}
    explicit Face(Node* node0, Node* node1, Node* node2):vert(){
        node[0] = node0;
        node[1] = node1;
        node[2] = node2;
    }
    explicit Face(Vert* vert0, Vert* vert1, Vert* vert2):node(){
        vert[0] = vert0;
        vert[1] = vert1;
        vert[2] = vert2;
    }
};

class Mesh{
public:
    std::vector<Node*> nodes;
    std::vector<Vert*> verts;
    std::vector<Face*> faces;
    std::vector<Norm*> norms;
    void add(Node* node);
    void add(Vert* vert);
    void add(Face* face);
    void add(Norm* norm);
};

void connect(Vert *vert, Node* node);

#endif