#ifndef UTILS_HPP
#define UTILS_HPP

#include <limits>

const double infinity = std::numeric_limits<double>::infinity();

template <typename T> 
T min (const T &a, const T &b, const T &c) {
    return std::min(a,std::min(b,c));
}
template <typename T> 
T min (const T &a, const T &b, const T &c, const T &d) {
    return std::min(std::min(a,b),std::min(c,d));
}

template <typename T> 
T max (const T &a, const T &b, const T &c) {
    return std::max(a,std::max(b,c));
}

template <typename T> 
T max (const T &a, const T &b, const T &c, const T &d) {
    return std::max(std::max(a,b),std::max(c,d));
}

template <typename T> T clamp (const T &x, const T &a, const T &b) {
    return std::min(std::max(x, a), b); 
}

template <typename T> 
inline int find (const T &x, const std::vector<T> &xs) {
    for (int i = 0; i < xs.size(); i++) 
        if (xs[i] == x) 
            return i; 
    return -1;
}

template <typename T> 
inline bool is_in (const T &x, const std::vector<T> &xs) {
    return find(x, xs) != -1;
}

template <typename T> 
inline void include (const T &x, std::vector<T> &xs) {
    if (!is_in(x, xs)) 
        xs.push_back(x);
}

#endif