#ifndef IO_HPP
#define IO_HPP
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <vector>
#include "vectors.hpp"
#include "mesh.hpp"
#include "utils.hpp"

void get_valid_line(std::istream &in, std::string &line);

void load_obj(Mesh &mesh, const std::string filename);

std::vector<Face*> triangulate (const std::vector<Vert*> &verts);

#endif