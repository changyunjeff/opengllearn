#include <iostream>
#include <gl/glut.h>
#include "callbacks.hpp"
#include "timer.hpp"
#include "io.hpp"

#define _USE_MATH_DEFINES
#include <math.h>
#include <cmath>

static bool running = false;
GLdouble x=0.0, y=0.0, z=10.0;
GLdouble lx=0.0, ly=0.0, lz=-1.0;
float angle_v = 0.0f;
Timer fps;
static Mesh mesh;


void idle()
{
    if(!::running)
        return;
    fps.tick();

    angle_v += M_PI/2;
    
    fps.tock();

    std::cout << "last: " << fps.last << std::endl;
    std::cout << "then: " <<fps.then << std::endl;
    std::cout << "total: " << fps.total << std::endl;

    glutPostRedisplay();
}

void draw_triangle_face(Node* node0, Node* node1, Node* node2)
{
    glVertex3f(node0->x[0],node0->x[1],node0->x[2]);
    glVertex3f(node1->x[0],node1->x[1],node1->x[2]);
    glVertex3f(node2->x[0],node2->x[1],node2->x[2]);
}

void display()
{
    glClearColor(0.1f, 0.2f, 0.3f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    gluLookAt(x, y, z, x+lx, y+ly, z+lz, 0, 1, 0);
    
    glRotatef(angle_v, 0.0f, 1.0f, 0.0f);
    glTranslatef(x, y, z);
    glColor3f(1.0f, 1.0f, 0.0f);
    
    glFrontFace(GL_CCW);//逆时针
    glCullFace(GL_BACK);
    glEnable(GL_CULL_FACE);
    glBegin(GL_TRIANGLES);
        for(int i=0;i<mesh.faces.size();i++){
            if(i%256==0){
                glEnd();
                glBegin(GL_TRIANGLES);
            }
            Face* face = mesh.faces[i];
            draw_triangle_face(face->node[0], face->node[1], face->node[2]);
        }
    glEnd();

    glutSwapBuffers();
}

static void keyboard(unsigned char key, int x, int y)
{
    const unsigned char esc = 27, space = ' ';
    if(key == esc)
        exit(EXIT_SUCCESS);
    else if(key == space)
        ::running =! ::running;
}

void special(int key, int x, int y)
{

}

void run_glut(GlutCallbacks &cb)
{
    int argc = 1;
    char argv0[] = "";
    char *argv = argv0;
    glutInit(&argc, &argv);
    glutInitDisplayMode(GLUT_RGBA|GLUT_DOUBLE|GLUT_DEPTH);
    glutInitWindowSize(640,380);
    int window = glutCreateWindow("ARCSim");
    glutDisplayFunc(display);
    glutReshapeFunc(cb.reshape);
    glutIdleFunc(cb.idle);
    glutKeyboardFunc(cb.keyboard);
    glutSpecialFunc(cb.special);
    glutMouseFunc(cb.mouse);
    glutMotionFunc(cb.motion);

    glEnable(GL_DEPTH_TEST);
    glutMainLoop();
}

int main(int argc, char** argv)
{
    load_obj(mesh, "./meshes/sphere.obj");
    GlutCallbacks cb;
    cb.idle = idle;
    cb.keyboard = keyboard;
    cb.special = special;
    cb.reshape = reshape;
    cb.mouse = mouse;
    cb.motion = motion;
    run_glut(cb);
    return 0;
}
