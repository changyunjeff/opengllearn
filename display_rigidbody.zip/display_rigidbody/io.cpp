#include "io.hpp"

#undef min

std::vector<Face*> triangulate(const std::vector<Node*> &nodes){
    int n = nodes.size();
    Node* node3;

    Node* node0 = nodes[0];
    Node* node1 = nodes[1];
    Node* node2 = nodes[2];
    if(nodes.size()>3)
        node3 = nodes[3];

    std::vector<Face*> tris;
    tris.push_back(new Face(node0, node1, node2));
    if(nodes.size()>3)
        tris.push_back(new Face(node0, node2, node3));

    return tris;
}

void get_valid_line(std::istream &in, std::string &line)
{
    do
        getline(in, line);
    while (in && (line.length() == 0 || line[0] == '#'));
}

void load_obj(Mesh &mesh, const std::string filename)
{
    std::fstream file(filename.c_str(), std::ios::in);
    if(!file){
        std::cout << "-- Error: failed to open file " << filename << std::endl;
        return;
    }
    while(!file.eof()){
        std::string line;
        get_valid_line(file, line);
        std::stringstream linestream(line);
        //std::cout << linestream.str() << std::endl;
        std::string keyword;
        linestream >> keyword;
        
        if(keyword=="v"){
            Vec3 x;
            linestream >> x[0] >> x[1] >> x[2];
            mesh.add(new Node(x));
        }else if(keyword=="vt"){//纹理坐标
            Vec2 u;
            linestream >> u[0] >> u[1];
            mesh.add(new Vert(u));
        } else if(keyword == "vn"){ // 顶点法向量
            Vec3 v;
            linestream >> v[0] >> v[1] >> v[2];
            mesh.add(new Norm(v));
        } else if(keyword == "f"){
            // vertex_index/texture_index/normal_index
            
            std::vector<Vert*> verts;
            std::vector<Node*> nodes;
            std::vector<Norm*> norms;
            std::string w;
            while(linestream >> w){
                std::stringstream wstream(w);
                //std::cout << wstream.str() << std::endl;
                int index1=-1, index2=-1, index3=-1;
                char c1, c2;// '/'
                wstream >> index1 >> c1 >> index2 >> c2 >> index3;
                
                nodes.push_back(mesh.nodes[index1-1]);
                if(index2>0)
                    verts.push_back(mesh.verts[index2-1]);
                if(index3>0)
                    norms.push_back(mesh.norms[index3-1]);
            }
            
            std::vector<Face*> faces = triangulate(nodes);
            for(int f=0;f<faces.size();f++)
                mesh.add(faces[f]);
        }
    }
    
}
